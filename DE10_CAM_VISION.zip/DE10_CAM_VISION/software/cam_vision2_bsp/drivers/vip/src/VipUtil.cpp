#include "VipUtil.hpp"

VipUtil::LogLevelType VipUtil::current_level = VipUtil::LOG_NONE;

