#ifndef mipi_setup
#define mipi_setup

#include "system.h"
#include "definitions.h"
#include "terasic_includes.h"
#include "alt_types.h"
#include "global.h"

#define MIPI_REG_PHYClkCtl		0x0056
#define MIPI_REG_PHYData0Ctl	0x0058
#define MIPI_REG_PHYData1Ctl	0x005A
#define MIPI_REG_PHYData2Ctl	0x005C
#define MIPI_REG_PHYData3Ctl	0x005E
#define MIPI_REG_PHYTimDly		0x0060
#define MIPI_REG_PHYSta			0x0062
#define MIPI_REG_CSIStatus		0x0064
#define MIPI_REG_CSIErrEn		0x0066
#define MIPI_REG_MDLSynErr		0x0068
#define MIPI_REG_FrmErrCnt		0x0080
#define MIPI_REG_MDLErrCnt		0x0090


void mipi_clear_error(void);

void mipi_show_error_info(void);

void mipi_show_error_info_more(void);

bool MIPI_Init(void);





#endif
