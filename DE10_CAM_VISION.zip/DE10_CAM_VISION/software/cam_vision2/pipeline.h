#ifndef PIPELINE
#define PIPELINE

#include "global.h"
#include "definitions.h"
#include "input.h"


void one_pipeline();
void three_pipelines();

#endif
