#ifndef INPUT
#define INPUT
	#include "system.h"
	#include "definitions.h"
	#include "alt_types.h"
	#include "support.h"
	#include "global.h"
	#include "filters_buffers.h"
	#include "auto.h"

	void process_input();
#endif
